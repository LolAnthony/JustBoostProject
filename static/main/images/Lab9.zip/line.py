from math_help import linear_function, k_b_from_two_points
from screen import BASE_SCREEN


class Line:
    def __init__(self, x1, y1, x2, y2, screen=BASE_SCREEN):
        self.screen = screen
        self.generate_route_points(x1, y1, x2, y2)

    def generate_route_points(self, x1, y1, x2, y2):
        lower_p, upper_p, direction = Line.sort_points((x1, y1), (x2, y2))
        route = Line.get_route_points(*lower_p, *upper_p, direction)
        self.route = route

    @staticmethod
    def sort_points(p1, p2):
        lower_p = min(p1, p2, key=lambda p: [p[1], p[0]])
        upper_p = p1 if p2 == lower_p else p2
        try:
            direction = (upper_p[0] - lower_p[0]) // abs(upper_p[0] - lower_p[0])
        except ZeroDivisionError:
            direction = 1
        return lower_p, upper_p, direction

    @staticmethod
    def get_route_points(x1, y1, x2, y2, direction):
        points = {(x1, y1), (x2, y2)}
        if x1 == x2:
            return points | {(x1, y) for y in range(y1, y2)}
        elif y1 == y2:
            return points | {(x1 + x, y1) for x in range(x2 * direction - x1 * direction)}

        k, b = k_b_from_two_points(x1, y1, x2, y2)
        i = 0.00
        while i < x2 * direction - x1 * direction:
            p_x = x1 + i * direction
            p_y = linear_function(p_x, k, b)
            points.add((round(p_x), round(p_y)))
            i += 0.01
        return points

    def draw(self, marker=""):
        self.screen.update(self.route)
        self.screen.show(marker)
