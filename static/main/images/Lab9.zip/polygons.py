from config import SYMBOL
from line import Line
from math_help import distance
from screen import BASE_SCREEN, Screen


class Polygon:
    def __init__(self, coords, screen=BASE_SCREEN):
        self.screen = screen
        self.set_coords(Polygon.unify_points(coords))

    @staticmethod
    def unify_points(points):
        unique_points = []
        for p in points:
            if p not in unique_points:
                unique_points.append(p)
        return unique_points

    def set_coords(self, coords):
        Polygon.check_coordinates(coords)
        self.coords = coords
        self.calculate_lines()

    @staticmethod
    def check_coordinates(coords):
        for p in coords:
            if not 0 <= p[0] < 40 or not 0 <= p[1] < 40:
                print("Некорректные координаты!")
                raise IndexError

    def calculate_lines(self):
        self.lines = []
        total_vertices = len(self.coords)
        for vi in range(total_vertices):
            v1, v2 = self.coords[vi], self.coords[(vi + 1) % total_vertices]
            self.lines.append(Line(*v1, *v2, self.screen))

    def draw(self, marker="", clear=False):
        if clear:
            self.screen.generate_field()
        for line in self.lines:
            self.screen.update(line.route)
        self.screen.show(marker)

    def __repr__(self):
        self.draw()
        return ""

    @property
    def area(self):
        s = Screen(self.screen.width, self.screen.height)
        for line in self.lines:
            s.update(line.route)
        total_area = 0
        for i in range(self.screen.height):
            for j in range(self.screen.width):
                p = s.field[i][j]
                if p == SYMBOL:
                    total_area += 1
                    continue
                borders = 0
                for up in range(i - 1, -1, -1):
                    if s.field[up][j] == SYMBOL:
                        borders += 1
                        break
                for down in range(i + 1, s.height):
                    if s.field[down][j] == SYMBOL:
                        borders += 1
                        break
                for right in range(j + 1, s.width):
                    if s.field[i][right] == SYMBOL:
                        borders += 1
                        break
                for left in range(j - 1, -1, -1):
                    if s.field[i][left] == SYMBOL:
                        borders += 1
                        break
                if borders == 4:
                    total_area += 1
        return total_area


class Rectangle(Polygon):
    def __init__(self, coords, screen=BASE_SCREEN):
        super().__init__(coords, screen)

    def set_coords(self, coords):
        Polygon.check_coordinates(coords)
        Rectangle.sort_coordinates(coords)
        Rectangle.check_rectangularity(coords)
        self.coords = coords
        self.calculate_lines()

    @staticmethod
    def check_rectangularity(coords):
        if len(coords) != 4:
            print("Координаты задают не прямоугольник!")
            raise ValueError
        lu, ru, rd, ld = coords
        if not (
                lu[1] == ru[1] and
                ld[1] == rd[1] and
                lu[0] == ld[0] and
                ru[0] == rd[0]
        ):
            print("Координаты задают не прямоугольник!")
            raise ValueError

    @staticmethod
    def sort_coordinates(coords):
        coords.sort(key=lambda p: [-p[1], p[0]])
        coords[2], coords[3] = coords[3], coords[2]

    @property
    def area(self):
        lu, ru, rd, ld = self.coords
        return round((ru[0] - lu[0]) * (lu[1] - ld[1]), 2)


class Triangle(Polygon):
    def __init__(self, coords, screen=BASE_SCREEN):
        super().__init__(coords, screen)

    def set_coords(self, coords):
        Polygon.check_coordinates(coords)
        Triangle.check_triangularity(coords)
        self.coords = coords
        self.calculate_lines()

    @staticmethod
    def check_triangularity(coords):
        if len(coords) != 3:
            print("Координаты задают не треугольник!")
            raise ValueError
        p1, p2, p3 = coords
        a, b, c = distance(*p1, *p2), distance(*p1, *p3), distance(*p2, *p3)
        if a + b <= c or a + c <= b or c + b <= a:
            print("Координаты задают не треугольник!")
            raise ValueError

    @property
    def area(self):
        v1, v2, v3 = self.coords
        a, b, c = distance(*v1, *v2), distance(*v1, *v3), distance(*v2, *v3)
        p = (a + b + c) / 2
        return round((p * (p - a) * (p - b) * (p - c)) ** 0.5, 2)


class Square(Rectangle):
    def __init__(self, coords, screen=BASE_SCREEN):
        super().__init__(coords, screen)

    def set_coords(self, coords):
        Polygon.check_coordinates(coords)
        Rectangle.sort_coordinates(coords)
        Rectangle.check_rectangularity(coords)
        Square.check_squarity(coords)
        self.coords = coords
        self.calculate_lines()

    @staticmethod
    def check_squarity(coords):
        if distance(*coords[0], *coords[1]) != distance(*coords[0], *coords[3]):
            print("Координаты задают не квадрат!")
            raise ValueError
