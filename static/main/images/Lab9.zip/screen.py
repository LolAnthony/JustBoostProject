from config import FIELD_WIDTH, FIELD_HEIGHT, SYMBOL


class Screen:
    def __init__(self, width=FIELD_WIDTH, height=FIELD_HEIGHT):
        self.width = width
        self.height = height
        self.generate_field()
        self.__boba = 9

    def generate_field(self):
        self.field = [[" " for __ in range(self.width)] for _ in range(self.height)]

    def update(self, coordinates, symbol=SYMBOL):
        for p in coordinates:
            self.field[p[1]][p[0]] = symbol

    def show(self, marker=""):
        print()
        for i in range(self.height - 1, -1, -1):
            print("-" * (self.width * 2 + 1))
            print("|" + "|".join(self.field[i]) + "|")
        print("-" * (FIELD_WIDTH * 2 + 1))
        print(f"↑ {marker}" if marker else marker)


BASE_SCREEN = Screen()
