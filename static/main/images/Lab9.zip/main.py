from line import Line
from polygons import Polygon, Rectangle, Triangle


def main():
    coordinates = [(15, 0), (0, 39), (39, 39), (20, 20), (39, 0)]
    p = Polygon(coordinates)
    p.draw("Первая фигура", True)
    for c in range(len(coordinates)):
        coordinates[c] = coordinates[c][0] // 2, coordinates[c][1] // 2
    p.set_coords(coordinates)
    p.draw("Первая фигурa перерисованная", True)

    rect_coordinates = [(5, 0), (0, 7), (5, 7), (0, 0)]
    r = Rectangle(rect_coordinates)
    r.draw("Прямоугольник", True)
    for c in range(len(rect_coordinates)):
        rect_coordinates[c] = rect_coordinates[c][0] // 2, rect_coordinates[c][1] // 2
    r.set_coords(rect_coordinates)
    r.draw("Перерисованный прямоугольник", True)

    triangle1 = [(0, 0), (20, 39), (0, 39)]
    triangle2 = [(7, 7), (20, 39), (39, 0)]
    rectangle1 = [(0, 0), (7, 19), (0, 19), (7, 0)]
    rectangle2 = [(3, 3), (7, 19), (3, 19), (7, 3)]
    figures = [
        Triangle(triangle1),
        Triangle(triangle2),
        Rectangle(rectangle1),
        Rectangle(rectangle2),
        Polygon(coordinates),
    ]
    for f in figures:
        f.draw("Какая-то фигура из массива", True)

    print(figures[3])

    print(sum(f.area for f in figures if issubclass(type(f), Polygon)))

    figures.append(Line(0, 0, 39, 39))
    print(sum(f.area for f in figures if issubclass(type(f), Polygon)))


if __name__ == "__main__":
    main()
